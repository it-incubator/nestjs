--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1.pgdg120+1)
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "BankSystem";
--
-- Name: BankSystem; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "BankSystem" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "BankSystem" OWNER TO postgres;

\connect "BankSystem"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Profiles" (
    "Hobby" character varying,
    "Education" character varying,
    "UserId" integer NOT NULL
);


ALTER TABLE public."Profiles" OWNER TO postgres;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    "Id" integer NOT NULL,
    "FirstName" character varying,
    "LastName" character varying,
    "PassportNumber" character varying,
    "IsMarried" boolean
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: Wallets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Wallets" (
    "Id" uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    "Title" character varying,
    "Currency" character(3),
    "OwnerId" integer
);


ALTER TABLE public."Wallets" OWNER TO postgres;

--
-- Name: UsersWithWalletsCount; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public."UsersWithWalletsCount"
WITH (autovacuum_enabled='true') AS
 SELECT "Id",
    "FirstName",
    "LastName",
    "PassportNumber",
    "IsMarried",
    ( SELECT count(*) AS count
           FROM public."Wallets"
          WHERE ("Wallets"."OwnerId" = u."Id")) AS "WalletCount"
   FROM public."Users" u
  WITH NO DATA;


ALTER MATERIALIZED VIEW public."UsersWithWalletsCount" OWNER TO postgres;

--
-- Name: UsersWithWalletsVountView; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."UsersWithWalletsVountView" AS
 SELECT "Id",
    "FirstName",
    "LastName",
    "PassportNumber",
    "IsMarried",
    ( SELECT count(*) AS count
           FROM public."Wallets"
          WHERE ("Wallets"."OwnerId" = u."Id")) AS "WalletCount"
   FROM public."Users" u;


ALTER VIEW public."UsersWithWalletsVountView" OWNER TO postgres;

--
-- Name: Users_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Users_Id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Users_Id_seq" OWNER TO postgres;

--
-- Name: Users_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Users_Id_seq" OWNED BY public."Users"."Id";


--
-- Name: WalletsSharings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WalletsSharings" (
    "Id" uuid DEFAULT public.uuid_generate_v1() NOT NULL,
    "WalletId" uuid,
    "UserId" integer,
    "AddedDate" date DEFAULT CURRENT_DATE,
    "Status" smallint
);


ALTER TABLE public."WalletsSharings" OWNER TO postgres;

--
-- Name: WalletsSharingsLimits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WalletsSharingsLimits" (
    "WalletSharingId" uuid NOT NULL,
    "LimitPerDay" integer,
    "LimitPerWeek" integer,
    "LimitPerMonth" integer
);


ALTER TABLE public."WalletsSharingsLimits" OWNER TO postgres;

--
-- Name: Users Id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users" ALTER COLUMN "Id" SET DEFAULT nextval('public."Users_Id_seq"'::regclass);


--
-- Data for Name: Profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Profiles" ("Hobby", "Education", "UserId") FROM stdin;
\.
COPY public."Profiles" ("Hobby", "Education", "UserId") FROM '$$PATH$$/3404.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" ("Id", "FirstName", "LastName", "PassportNumber", "IsMarried") FROM stdin;
\.
COPY public."Users" ("Id", "FirstName", "LastName", "PassportNumber", "IsMarried") FROM '$$PATH$$/3405.dat';

--
-- Data for Name: Wallets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Wallets" ("Id", "Title", "Currency", "OwnerId") FROM stdin;
\.
COPY public."Wallets" ("Id", "Title", "Currency", "OwnerId") FROM '$$PATH$$/3406.dat';

--
-- Data for Name: WalletsSharings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WalletsSharings" ("Id", "WalletId", "UserId", "AddedDate", "Status") FROM stdin;
\.
COPY public."WalletsSharings" ("Id", "WalletId", "UserId", "AddedDate", "Status") FROM '$$PATH$$/3409.dat';

--
-- Data for Name: WalletsSharingsLimits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WalletsSharingsLimits" ("WalletSharingId", "LimitPerDay", "LimitPerWeek", "LimitPerMonth") FROM stdin;
\.
COPY public."WalletsSharingsLimits" ("WalletSharingId", "LimitPerDay", "LimitPerWeek", "LimitPerMonth") FROM '$$PATH$$/3410.dat';

--
-- Name: Users_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Users_Id_seq"', 5, true);


--
-- Name: Profiles Profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Profiles"
    ADD CONSTRAINT "Profiles_pkey" PRIMARY KEY ("UserId");


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY ("Id");


--
-- Name: WalletsSharingsLimits WalletsSharingsLimits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletsSharingsLimits"
    ADD CONSTRAINT "WalletsSharingsLimits_pkey" PRIMARY KEY ("WalletSharingId");


--
-- Name: WalletsSharings WalletsSharings_WalletId_UserId_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletsSharings"
    ADD CONSTRAINT "WalletsSharings_WalletId_UserId_key" UNIQUE ("WalletId", "UserId");


--
-- Name: WalletsSharings WalletsSharings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletsSharings"
    ADD CONSTRAINT "WalletsSharings_pkey" PRIMARY KEY ("Id");


--
-- Name: Wallets Wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Wallets"
    ADD CONSTRAINT "Wallets_pkey" PRIMARY KEY ("Id");


--
-- Name: Profiles Profiles_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Profiles"
    ADD CONSTRAINT "Profiles_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id");


--
-- Name: WalletsSharingsLimits WalletsSharingsLimits_WalletSharingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletsSharingsLimits"
    ADD CONSTRAINT "WalletsSharingsLimits_WalletSharingId_fkey" FOREIGN KEY ("WalletSharingId") REFERENCES public."Wallets"("Id");


--
-- Name: WalletsSharings WalletsSharings_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletsSharings"
    ADD CONSTRAINT "WalletsSharings_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."Users"("Id");


--
-- Name: WalletsSharings WalletsSharings_WalletId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WalletsSharings"
    ADD CONSTRAINT "WalletsSharings_WalletId_fkey" FOREIGN KEY ("WalletId") REFERENCES public."Wallets"("Id");


--
-- Name: Wallets Wallets_OwnerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Wallets"
    ADD CONSTRAINT "Wallets_OwnerId_fkey" FOREIGN KEY ("OwnerId") REFERENCES public."Users"("Id") NOT VALID;


--
-- Name: UsersWithWalletsCount; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: postgres
--

REFRESH MATERIALIZED VIEW public."UsersWithWalletsCount";


--
-- PostgreSQL database dump complete
--

